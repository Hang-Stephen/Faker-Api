const faker = require('faker');

const express = require('express');
const { application } = require('express');
const app = express();
const port = 8000;

const createUser = () => ({
    _id: faker.datatype.uuid(),
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    phoneNumber: faker.phone.phoneNumber(),
    email: faker.internet.email(),
    password: faker.internet.password()
});

const createCompany = () => ({
    _id: faker.datatype.uuid(),
    name: faker.company.name(),
    address: {
        street: faker.address.streetAddress(),
        city: faker.address.city(),
        state: faker.address.state(),
        zipCode: faker.address.zipCode(),
        country: faker.address.country()
    }
})

app.get("/api/users/new", (req, res) => {
    const user = createUser();
    res.json(user);
});

app.get("/api/companies/new", (req, res) => {
    const company = createCompany();
    res.json(company);
});

app.get("/api/user/companny", (req, res) => {
    const user = createUser();
    const company = createCompany();
    const combinedObject = {
        newUser: user,
        newCompany: company
    };
    res.json(combinedObject);

});


app.listen(port, () => console.log('Listening on port: ${port}') );